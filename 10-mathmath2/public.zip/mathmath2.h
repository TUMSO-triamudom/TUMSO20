#include<vector>

#ifndef MATHMATH_H
#define MATHMATH_H

int init();
long long GCD(int i, int j);
long long LCM(int i, int j, int k);
void answer(std::vector<int> ans);

#endif